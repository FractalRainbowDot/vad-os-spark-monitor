#!/bin/bash
set -e
HERE="$(cd -- "$(dirname "$0")" && pwd -P)"
unset PYTHONHOME PYTHONPATH
export PYTHONNOUSERSITE=1
"$HERE/runtime/bin/python3" "$HERE/spark-monitor.pyz" --save-key
