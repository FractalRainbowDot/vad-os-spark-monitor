#!/bin/bash
set -e

HERE="$(cd -- "$(dirname "$0")" && pwd -P)"
PYTHON="$HERE/runtime/bin/python3"
MONITOR="$HERE/spark-monitor.pyz"

if [ "$(uname -s)" != "Darwin" ]; then
    echo 'Эта сборка предназначена для macOS с Apple Silicon (M1 и новее, включая M5).'
    exit 1
fi

unset PYTHONHOME PYTHONPATH
export PYTHONNOUSERSITE=1
export TERM="${TERM:-xterm-256color}"

if [ ! -s "$HERE/.env" ] && [ -z "${LITELLM_API_KEY:-}" ]; then
    echo 'Первый запуск: сохраните свой ключ LiteLLM. Ввод скрытый.'
    "$PYTHON" "$MONITOR" --save-key
fi

exec "$PYTHON" "$MONITOR" "$@"
